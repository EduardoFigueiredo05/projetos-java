package arraytipado;


public class Pessoa {
    
    
        String nome;
        String email;
        String telefone;
        int idade;
    
}

